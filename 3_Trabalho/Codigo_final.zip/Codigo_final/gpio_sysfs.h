extern int setGPIO_Out(int);
extern int GPIO_Write(int, int);
extern int setGPIO_In(int, char*);
extern int GPIO_Read(int);
extern int unsetGPIO(int);
