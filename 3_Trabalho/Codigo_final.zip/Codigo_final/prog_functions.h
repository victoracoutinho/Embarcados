void init_camera();
void take_photo();
void reco_char();
void speak();
void dc_camera();
void read_continue(int);
